
		for	(var index = 0; index < 50; index++) {
			for	(var jindex = 0; jindex < 100; jindex++) {
				map[index][jindex] = 0;
			}
	}
		
